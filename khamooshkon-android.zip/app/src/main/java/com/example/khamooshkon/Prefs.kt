package com.example.khamooshkon

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun selected(c: Context): MutableSet<String> =
        HashSet(sp(c).getStringSet("sel", emptySet()) ?: emptySet())

    fun setSelected(c: Context, set: Set<String>) {
        sp(c).edit().putStringSet("sel", HashSet(set)).apply()
    }
}
