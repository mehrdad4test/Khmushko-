package com.example.khamooshkon

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: AppAdapter
    private lateinit var rv: RecyclerView
    private lateinit var count: TextView
    private lateinit var banner: TextView
    private lateinit var tabMine: TextView
    private lateinit var tabAll: TextView
    private lateinit var search: EditText

    private var allApps: List<AppItem> = emptyList()
    private val selected: MutableSet<String> = mutableSetOf()
    private var mineTab = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rv = findViewById(R.id.rv)
        count = findViewById(R.id.count)
        banner = findViewById(R.id.banner)
        tabMine = findViewById(R.id.tabMine)
        tabAll = findViewById(R.id.tabAll)
        search = findViewById(R.id.search)

        selected.addAll(Prefs.selected(this))

        adapter = AppAdapter { pkg, on ->
            if (on) selected.add(pkg) else selected.remove(pkg)
            Prefs.setSelected(this, selected)
            CloseAllWidget.refresh(this)
            updateCount()
            if (mineTab) rv.post { applyFilter() }
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<TextView>(R.id.btnList).setOnClickListener {
            withService { it.forceStopSelected() }
        }
        findViewById<TextView>(R.id.btnRecents).setOnClickListener {
            withService { it.closeRecents() }
        }
        banner.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        tabMine.setOnClickListener { mineTab = true; styleTabs(); applyFilter() }
        tabAll.setOnClickListener { mineTab = false; styleTabs(); applyFilter() }
        search.doAfterTextChanged { applyFilter() }

        styleTabs()
        updateCount()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        banner.visibility = if (ForceStopService.instance == null) TextView.VISIBLE else TextView.GONE
    }

    private fun withService(block: (ForceStopService) -> Unit) {
        val s = ForceStopService.instance
        if (s == null) {
            Toast.makeText(this, "اول سرویس خاموش‌کن را در تنظیمات دسترسی‌پذیری فعال کنید", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            block(s)
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(launcher, 0)
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .filter { it.pkg != packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim()
        val list = allApps.filter {
            (!mineTab || it.pkg in selected) &&
                (q.isEmpty() || it.label.contains(q, true) || it.pkg.contains(q, true))
        }
        adapter.submit(list, selected)
        updateCount()
    }

    private fun updateCount() {
        count.text = "${selected.size} برنامه در لیست شما"
    }

    private fun styleTabs() {
        val on = Color.parseColor("#F2F5F8")
        val off = Color.parseColor("#8B95A5")
        tabMine.setBackgroundResource(if (mineTab) R.drawable.bg_tab_active else 0)
        tabAll.setBackgroundResource(if (mineTab) 0 else R.drawable.bg_tab_active)
        tabMine.setTextColor(if (mineTab) on else off)
        tabAll.setTextColor(if (mineTab) off else on)
    }
}
