package com.example.khamooshkon

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

class CloseAllWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_RUN = "com.example.khamooshkon.RUN"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, CloseAllWidget::class.java))
            if (ids.isNotEmpty()) update(c, m, ids)
        }

        fun update(c: Context, m: AppWidgetManager, ids: IntArray) {
            val rv = RemoteViews(c.packageName, R.layout.widget_layout)
            rv.setTextViewText(R.id.w_sub, "${Prefs.selected(c).size} برنامه در لیست")
            val pi = PendingIntent.getBroadcast(
                c, 0,
                Intent(c, CloseAllWidget::class.java).setAction(ACTION_RUN),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            ids.forEach { m.updateAppWidget(it, rv) }
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        update(context, manager, ids)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_RUN) {
            val s = ForceStopService.instance
            if (s == null) {
                Toast.makeText(context, "سرویس خاموش‌کن در تنظیمات دسترسی‌پذیری فعال نیست", Toast.LENGTH_LONG).show()
            } else {
                s.runFull()
            }
        }
    }
}
