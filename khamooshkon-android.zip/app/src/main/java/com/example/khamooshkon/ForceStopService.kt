package com.example.khamooshkon

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.ActivityManager
import android.content.Intent
import android.graphics.Path
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class ForceStopService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ForceStopService? = null
        private const val SETTINGS = "com.android.settings"
    }

    private val h = Handler(Looper.getMainLooper())
    private var queue: ArrayDeque<String> = ArrayDeque()
    private var busy = false
    private var tries = 0
    private var confirmed = false
    private var onDone: (() -> Unit)? = null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- public actions ----------

    fun runFull() {
        forceStopSelected { closeRecents() }
    }

    fun forceStopSelected(done: (() -> Unit)? = null) {
        if (busy) return
        val pkgs = Prefs.selected(this).filter { it != packageName }
        killBackground(pkgs)
        if (pkgs.isEmpty()) {
            toast("لیست خالی است")
            done?.invoke()
            return
        }
        busy = true
        onDone = done
        queue = ArrayDeque(pkgs)
        next()
    }

    fun closeRecents(done: (() -> Unit)? = null) {
        if (busy) return
        killBackground(launcherPackages())
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        tries = 0
        h.postDelayed({ pollRecents(done) }, 1000)
    }

    // ---------- force stop flow ----------

    private fun next() {
        val p = queue.removeFirstOrNull()
        if (p == null) {
            busy = false
            val d = onDone
            onDone = null
            if (d == null) {
                performGlobalAction(GLOBAL_ACTION_HOME)
                toast("انجام شد")
            } else {
                d.invoke()
            }
            return
        }
        tries = 0
        confirmed = false
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", p, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            h.post { next() }
            return
        }
        h.postDelayed({ poll() }, 800)
    }

    private fun poll() {
        val root = rootInActiveWindow
        if (root != null) {
            if (!confirmed) {
                val f = findByTexts(root, forceStopTexts())
                if (f != null) {
                    if (!f.isEnabled) {
                        leave()
                        return
                    }
                    if (click(f)) {
                        confirmed = true
                        tries = 0
                        h.postDelayed({ poll() }, 500)
                        return
                    }
                }
            } else {
                val ok = root.findAccessibilityNodeInfosByViewId("android:id/button1").firstOrNull()
                    ?: findByTexts(root, okTexts())
                if (ok != null) {
                    click(ok)
                    h.postDelayed({ leave() }, 500)
                    return
                }
            }
        }
        tries++
        if (tries > 20) leave() else h.postDelayed({ poll() }, 300)
    }

    private fun leave() {
        performGlobalAction(GLOBAL_ACTION_BACK)
        h.postDelayed({ next() }, 500)
    }

    // ---------- recents flow ----------

    private fun pollRecents(done: (() -> Unit)?) {
        val root = rootInActiveWindow
        if (root != null) {
            val texts = mutableListOf("Clear all", "Close all", "پاک کردن همه", "بستن همه")
            val pkg = root.packageName?.toString()
            if (pkg != null) stringFrom("recents_clear_all", pkg)?.let { texts.add(0, it) }
            val n = findByTexts(root, texts)
            if (n != null && click(n)) {
                h.postDelayed({
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    toast("انجام شد")
                    done?.invoke()
                }, 700)
                return
            }
        }
        tries++
        if (tries == 3) swipe(0.2f, 0.9f)
        if (tries == 5) swipe(0.9f, 0.2f)
        if (tries > 9) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            toast("دکمه Clear all پیدا نشد")
            done?.invoke()
        } else {
            h.postDelayed({ pollRecents(done) }, 400)
        }
    }

    private fun swipe(fromFrac: Float, toFrac: Float) {
        val dm = resources.displayMetrics
        val y = dm.heightPixels * 0.5f
        val path = Path().apply {
            moveTo(dm.widthPixels * fromFrac, y)
            lineTo(dm.widthPixels * toFrac, y)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- helpers ----------

    private fun killBackground(pkgs: Collection<String>) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        pkgs.forEach { am.killBackgroundProcesses(it) }
    }

    private fun launcherPackages(): List<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .filter { it != packageName }
            .distinct()
    }

    private fun stringFrom(name: String, pkg: String): String? = try {
        val r = packageManager.getResourcesForApplication(pkg)
        val id = r.getIdentifier(name, "string", pkg)
        if (id != 0) r.getString(id) else null
    } catch (e: Exception) {
        null
    }

    private fun forceStopTexts(): List<String> {
        val l = mutableListOf("Force stop", "Force Stop", "توقف اجباری")
        stringFrom("force_stop", SETTINGS)?.let { l.add(0, it) }
        return l
    }

    private fun okTexts(): List<String> =
        listOf(getString(android.R.string.ok), "OK", "تأیید", "تایید")

    private fun findByTexts(root: AccessibilityNodeInfo, texts: List<String>): AccessibilityNodeInfo? {
        for (t in texts) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val a = n.text?.toString()
                val b = n.contentDescription?.toString()
                if (a.equals(t, true) || b.equals(t, true)) return n
            }
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
