package com.example.khamooshkon

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

class AppAdapter(private val onToggle: (String, Boolean) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()
    private var selected: Set<String> = emptySet()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val name: TextView = v.findViewById(R.id.name)
        val pkg: TextView = v.findViewById(R.id.pkg)
        val sw: SwitchCompat = v.findViewById(R.id.sw)
    }

    fun submit(list: List<AppItem>, sel: Set<String>) {
        items = list
        selected = sel
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val a = items[position]
        h.icon.setImageDrawable(a.icon)
        h.name.text = a.label
        h.pkg.text = a.pkg
        h.sw.setOnCheckedChangeListener(null)
        h.sw.isChecked = a.pkg in selected
        h.sw.setOnCheckedChangeListener { _, checked -> onToggle(a.pkg, checked) }
    }
}
